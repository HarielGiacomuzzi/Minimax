/**********************************************************************
 *  Adversarial Search readme.txt template
 **********************************************************************/


Name:Hariel Giacomuzzi
Student ID:13104441-4


Hours to complete assignment (optional):


/**********************************************************************
 *  Explain briefly how you implemented the helper methods for 
 * \texttt{get_next_move()}.
 **********************************************************************/
i’ve implemented methods for creating the tree of decisions and methods to operate on this tree




/**********************************************************************
 *  Explain briefly how you represented the utility of the end game. 
 * Did you use different values for different end configurations?
 **********************************************************************/

i tried to use the len function and use the remaining spaces from the board to 
get the most valuable movement but it does not work soo well





/**********************************************************************
 *  Explain briefly how you generated the successor moves.
 **********************************************************************/

for each index of the get empty cell method i created a tree node with that movement



/**********************************************************************
 *  How often does your player wins when it plays as X against a 
 * randomizing player, and how often does it wins when it plays as O?
 **********************************************************************/

if i begin the game i always win but if i don’t sometimes i loose and still trying to figure out why

/**********************************************************************
 *  If you wanted to solve some other games using variations of minimax 
 * (such as the ones seen in class), which ones would you use, and how 
 * would you integrate them into this code? Why?
 **********************************************************************/






/**********************************************************************
 *  If you did the extra credit, describe your algorithm briefly and
 *  state the order of growth of the running time (in the worst case)
 *  for \texttt{get_next_move()}.
 **********************************************************************/

start to worked on it but can’t finish this, besides the alpha beta is not soo hard of 
implementing once we have a minimax done i can’t finish because my minimax
implementation was not soo good


/**********************************************************************
 *  Known bugs / limitations.
 **********************************************************************/
there’s a bug when some states does not have a value associated with it and can’t figure out why probably i forget to assignee something and if i don’t begin the game i loose sometimes


/**********************************************************************
 *  Describe whatever help (if any) that you received.
 *  Don't include readings, lectures, and precepts, but do
 *  include any help from people (including staff, classmates, and 
 *  friends) and attribute them by name.
 **********************************************************************/

i have talked about the algorithm and the evaluating function with Leonardo Gubert



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/


i’ve reader the book a lot of times and try to implement as it is but somehow i can’t make it work as well :( and this is very sad :’(

/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **********************************************************************/
